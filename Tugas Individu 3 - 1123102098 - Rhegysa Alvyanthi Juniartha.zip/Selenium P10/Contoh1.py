from selenium import webdriver

URL = 'https://id.indeed.com/jobs?'
params = {
    'q' : 'graphic designer',
    'l' : 'Surabaya'
};

headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36'}
driver = webdriver.Chrome()
fullURL = f"{URL}&q={params['q']}&l={params['l']}"
driver.get(fullURL);
html = driver.page_source
print(html)